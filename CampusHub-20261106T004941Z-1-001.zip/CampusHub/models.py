"""Defines the data structures/classes for things like equipment, borrowers, and loans."""

class Equipment:
    def __init__(self, asset_code, name, category, location, condition="Good"):
        self.asset_code = asset_code
        self.name = name
        self.category = category
        self.location = location
        self.condition = condition

    def __str__(self):
        return f"{self.asset_code} - {self.name}"

class Borrower:
    def __init__(self, borrower_code, display_name, department):
        self.borrower_code = borrower_code
        self.display_name = display_name
        self.department = department
