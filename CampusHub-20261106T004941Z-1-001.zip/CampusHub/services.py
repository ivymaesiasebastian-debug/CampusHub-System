"""Handles the main operations: adding equipment, registering borrowers, checkout, returns, and updates."""

from datetime import date
import sqlite3
from database import get_connection
from models import Equipment, Borrower
from validators import required, valid_loan_dates


def add_equipment(asset_code, name, category, location, condition):
    if not required(asset_code, name, category, location, condition):
        raise ValueError("Please complete all equipment fields.")
    item = Equipment(asset_code.strip(), name.strip(), category.strip(), location.strip(), condition.strip())
    with get_connection() as conn:
        conn.execute("""INSERT INTO equipment(asset_code,name,category,location,condition,status)
                        VALUES(?,?,?,?,?,'Available')""",
                     (item.asset_code, item.name, item.category, item.location, item.condition))


def update_equipment(asset_id, name, category, location, condition):
    if not required(name, category, location, condition):
        raise ValueError("Please complete all equipment detail fields.")
    with get_connection() as conn:
        cur = conn.execute("UPDATE equipment SET name=?,category=?,location=?,condition=? WHERE asset_id=? AND status!='Inactive'",
                           (name.strip(), category.strip(), location.strip(), condition.strip(), asset_id))
        if cur.rowcount == 0:
            raise ValueError("Equipment not found or already inactive.")


def deactivate_equipment(asset_id):
    """Archive an asset without deleting its loan history."""
    with get_connection() as conn:
        row = conn.execute("SELECT status FROM equipment WHERE asset_id=?", (asset_id,)).fetchone()
        if row is None:
            raise ValueError("Equipment record not found.")
        if row["status"] == "Borrowed":
            raise ValueError("Return the borrowed equipment before marking it inactive.")
        if row["status"] == "Inactive":
            raise ValueError("Equipment is already inactive.")
        conn.execute("UPDATE equipment SET status='Inactive' WHERE asset_id=?", (asset_id,))


def add_borrower(code, name, department):
    if not required(code, name, department):
        raise ValueError("Please complete all borrower fields.")
    borrower = Borrower(code.strip(), name.strip(), department.strip())
    with get_connection() as conn:
        conn.execute("INSERT INTO borrowers(borrower_code,display_name,department_or_program) VALUES(?,?,?)",
                     (borrower.borrower_code, borrower.display_name, borrower.department))


def list_equipment(search="", include_inactive=True):
    query = "SELECT * FROM equipment WHERE (asset_code LIKE ? OR name LIKE ?)"
    params = [f"%{search}%", f"%{search}%"]
    if not include_inactive:
        query += " AND status!='Inactive'"
    query += " ORDER BY asset_code"
    with get_connection() as conn:
        return conn.execute(query, params).fetchall()


def list_borrowers(search="", include_inactive=False):
    query = "SELECT * FROM borrowers WHERE (borrower_code LIKE ? OR display_name LIKE ?)"
    params = [f"%{search}%", f"%{search}%"]
    if not include_inactive:
        query += " AND active=1"
    query += " ORDER BY display_name"
    with get_connection() as conn:
        return conn.execute(query, params).fetchall()


def checkout(asset_id, borrower_id, borrowed_on, due_on):
    if not valid_loan_dates(borrowed_on, due_on):
        raise ValueError("Enter valid dates in YYYY-MM-DD format. Due date cannot be before borrow date.")
    with get_connection() as conn:
        asset = conn.execute("SELECT status FROM equipment WHERE asset_id=?", (asset_id,)).fetchone()
        borrower = conn.execute("SELECT active FROM borrowers WHERE borrower_id=?", (borrower_id,)).fetchone()
        # Required if-elif-else branching: distinguish missing, unavailable, and valid assets.
        if asset is None:
            raise ValueError("Equipment record not found.")
        elif asset["status"] != "Available":
            raise ValueError("This equipment is not available for checkout.")
        elif borrower is None or borrower["active"] != 1:
            raise ValueError("Borrower is inactive or does not exist.")
        else:
            conn.execute("INSERT INTO loans(asset_id,borrower_id,borrowed_on,due_on,status) VALUES(?,?,?,?, 'Active')",
                         (asset_id, borrower_id, borrowed_on, due_on))
            conn.execute("UPDATE equipment SET status='Borrowed' WHERE asset_id=?", (asset_id,))


def return_loan(loan_id):
    today = date.today().isoformat()
    with get_connection() as conn:
        loan = conn.execute("SELECT asset_id,status FROM loans WHERE loan_id=?", (loan_id,)).fetchone()
        if loan is None:
            raise ValueError("Loan record not found.")
        elif loan["status"] != "Active":
            raise ValueError("This loan has already been returned.")
        else:
            conn.execute("UPDATE loans SET returned_on=?,status='Returned' WHERE loan_id=?", (today, loan_id))
            conn.execute("UPDATE equipment SET status='Available' WHERE asset_id=?", (loan["asset_id"],))


def list_loans():
    with get_connection() as conn:
        rows = conn.execute("""SELECT l.loan_id,e.asset_code,e.name AS equipment_name,
            b.borrower_code,b.display_name,l.borrowed_on,l.due_on,l.returned_on,l.status
            FROM loans l JOIN equipment e ON e.asset_id=l.asset_id
            JOIN borrowers b ON b.borrower_id=l.borrower_id ORDER BY l.loan_id DESC""").fetchall()
    today = date.today().isoformat()
    result = []
    for row in rows:
        data = dict(row)
        data["display_status"] = "Overdue" if data["status"] == "Active" and data["due_on"] < today else data["status"]
        result.append(data)
    return result


def dashboard_counts():
    with get_connection() as conn:
        total = conn.execute("SELECT COUNT(*) FROM equipment WHERE status!='Inactive'").fetchone()[0]
        available = conn.execute("SELECT COUNT(*) FROM equipment WHERE status='Available'").fetchone()[0]
        active = conn.execute("SELECT COUNT(*) FROM loans WHERE status='Active'").fetchone()[0]
    overdue = sum(1 for loan in list_loans() if loan["display_status"] == "Overdue")
    return total, available, active, overdue


def dispatch_action(action, *args):
    """Route real application actions using Python match-case."""
    match action:
        case "checkout":
            return checkout(*args)
        case "return":
            return return_loan(*args)
        case "counts":
            return dashboard_counts()
        case "overdue":
            return [loan for loan in list_loans() if loan["display_status"] == "Overdue"]
        case _:
            raise ValueError("Unknown application action.")
