"""Tkinter graphical user interface."""
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date
import sqlite3

from services import (
    add_equipment, update_equipment, deactivate_equipment, add_borrower, list_equipment,
    list_borrowers, list_loans, dispatch_action
)
from reports import get_dashboard_report


class CampusHubApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("CampusHub - School Resource Borrowing and Inventory")
        self.geometry("1100x720")
        self.minsize(900, 600)
        self.configure(padx=12, pady=12)

        title = ttk.Label(self, text="CampusHub", font=("Segoe UI", 50, "bold"))
        title.pack(anchor="w")
        ttk.Label(
            self,
            text="School Resource Borrowing and Inventory Management System",
            font=("Segoe UI", 15)
        ).pack(anchor="w", pady=(0, 10))

        style = ttk.Style()

        style.configure(
            "TNotebook.Tab",
            font=("Arial", 12, "bold"),
            padding=(20, 12)
        )

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True)

        self.inventory_tab = ttk.Frame(self.tabs, padding=10)
        self.borrowers_tab = ttk.Frame(self.tabs, padding=10)
        self.loans_tab = ttk.Frame(self.tabs, padding=10)
        self.dashboard_tab = ttk.Frame(self.tabs, padding=10)

        self.tabs.add(self.dashboard_tab, text="Dashboard")
        self.tabs.add(self.inventory_tab, text="Inventory")
        self.tabs.add(self.borrowers_tab, text="Borrowers")
        self.tabs.add(self.loans_tab, text="Loans / Returns")

        self.build_dashboard()
        self.build_inventory()
        self.build_borrowers()
        self.build_loans()
        self.refresh_all()

    def make_tree(self, parent, columns, headings):
        tree = ttk.Treeview(parent, columns=columns, show="headings", height=12)

        for col, heading in zip(columns, headings):
            tree.heading(col, text=heading)
            tree.column(col, width=125, anchor="w")

        tree.pack(fill="both", expand=True, pady=8)
        return tree

    def build_dashboard(self):
        dashboard_content = ttk.Frame(self.dashboard_tab)
        dashboard_content.place(relx=0.5, rely=0.5, anchor="center")

        ttk.Label(
            dashboard_content,
            text="System Overview",
            font=("Segoe UI", 40, "bold")
        ).pack(anchor="center")

        self.dashboard_text = tk.StringVar()

        ttk.Label(
            dashboard_content,
            textvariable=self.dashboard_text,
            font=("Segoe UI", 13),
            justify="center"
        ).pack(anchor="center", pady=18)

        style = ttk.Style()
        style.configure(
            "Dashboard.TButton",
            font=("Segoe UI", 16, "bold"),
            padding=(25, 15)
        )

        ttk.Button(
            dashboard_content,
            text="Refresh Dashboard",
            command=self.refresh_dashboard,
            style="Dashboard.TButton",
            width=25
        ).pack(anchor="center", pady=10)

    def build_inventory(self):
        form = ttk.LabelFrame(
            self.inventory_tab,
            text="Equipment Details",
            padding=10
        )
        form.pack(fill="x")

        self.asset_fields = {}
        labels = ["Asset Code", "Name", "Category", "Location", "Condition"]

        for i, label in enumerate(labels):
            ttk.Label(form, text=label).grid(
                row=0, column=i, padx=4, sticky="w"
            )
            entry = ttk.Entry(form, width=18)
            entry.grid(row=1, column=i, padx=4, pady=4)
            self.asset_fields[label] = entry

        ttk.Button(
            form, text="Add Equipment", command=self.add_asset
        ).grid(row=1, column=5, padx=6)

        ttk.Button(
            form, text="Update Selected", command=self.update_asset
        ).grid(row=1, column=6, padx=6)

        searchrow = ttk.Frame(self.inventory_tab)
        searchrow.pack(fill="x", pady=(10, 0))

        ttk.Label(searchrow, text="Search code/name:").pack(side="left")

        self.asset_search = tk.StringVar()

        ttk.Entry(
            searchrow,
            textvariable=self.asset_search,
            width=30
        ).pack(side="left", padx=6)

        ttk.Button(
            searchrow, text="Search", command=self.refresh_inventory
        ).pack(side="left")

        ttk.Button(
            searchrow,
            text="Show All",
            command=lambda: (
                self.asset_search.set(""),
                self.refresh_inventory()
            )
        ).pack(side="left", padx=4)

        cols = ("id", "code", "name", "category", "location", "condition", "status")

        self.asset_tree = self.make_tree(
            self.inventory_tab,
            cols,
            ("ID", "Asset Code", "Name", "Category", "Location", "Condition", "Status")
        )

        self.asset_tree.column("id", width=45)
        self.asset_tree.bind("<<TreeviewSelect>>", self.load_selected_asset)

        ttk.Button(
            self.inventory_tab,
            text="Mark Selected Inactive",
            command=self.archive_asset
        ).pack(anchor="e", pady=(0, 6))

    def build_borrowers(self):
        form = ttk.LabelFrame(
            self.borrowers_tab,
            text="Register Borrower",
            padding=10
        )
        form.pack(fill="x")

        self.borrower_fields = {}
        labels = ["Borrower Code", "Full Name", "Department / Program"]

        for i, label in enumerate(labels):
            ttk.Label(form, text=label).grid(
                row=0, column=i, padx=5, sticky="w"
            )
            entry = ttk.Entry(form, width=28)
            entry.grid(row=1, column=i, padx=5, pady=5)
            self.borrower_fields[label] = entry

        ttk.Button(
            form,
            text="Register Borrower",
            command=self.add_person
        ).grid(row=1, column=3, padx=8)

        searchrow = ttk.Frame(self.borrowers_tab)
        searchrow.pack(fill="x", pady=(10, 0))

        ttk.Label(searchrow, text="Search code/name:").pack(side="left")

        self.borrower_search = tk.StringVar()

        ttk.Entry(
            searchrow,
            textvariable=self.borrower_search,
            width=30
        ).pack(side="left", padx=6)

        ttk.Button(
            searchrow,
            text="Search",
            command=self.refresh_borrowers
        ).pack(side="left")

        ttk.Button(
            searchrow,
            text="Show All",
            command=lambda: (
                self.borrower_search.set(""),
                self.refresh_borrowers()
            )
        ).pack(side="left", padx=4)

        self.borrower_tree = self.make_tree(
            self.borrowers_tab,
            ("id", "code", "name", "department"),
            ("ID", "Borrower Code", "Name", "Department / Program")
        )

        self.borrower_tree.column("id", width=45)

    def build_loans(self):
        form = ttk.LabelFrame(
            self.loans_tab,
            text="Checkout Equipment",
            padding=10
        )
        form.pack(fill="x")

        ttk.Label(form, text="Equipment").grid(
            row=0, column=0, sticky="w", padx=5
        )
        ttk.Label(form, text="Borrower").grid(
            row=0, column=1, sticky="w", padx=5
        )
        ttk.Label(form, text="Borrow date (YYYY-MM-DD)").grid(
            row=0, column=2, sticky="w", padx=5
        )
        ttk.Label(form, text="Due date (YYYY-MM-DD)").grid(
            row=0, column=3, sticky="w", padx=5
        )

        self.asset_choice = ttk.Combobox(
            form, width=28, state="readonly"
        )
        self.borrower_choice = ttk.Combobox(
            form, width=28, state="readonly"
        )

        self.borrow_date = ttk.Entry(form, width=16)
        self.due_date = ttk.Entry(form, width=16)

        self.borrow_date.insert(0, date.today().isoformat())
        self.due_date.insert(0, date.today().isoformat())

        self.asset_choice.grid(row=1, column=0, padx=5, pady=5)
        self.borrower_choice.grid(row=1, column=1, padx=5, pady=5)
        self.borrow_date.grid(row=1, column=2, padx=5, pady=5)
        self.due_date.grid(row=1, column=3, padx=5, pady=5)

        ttk.Button(
            form,
            text="Checkout",
            command=self.do_checkout
        ).grid(row=1, column=4, padx=8)

        ttk.Label(
            self.loans_tab,
            text="Select an active loan below, then click Return Selected."
        ).pack(anchor="w", pady=(12, 0))

        ttk.Button(
            self.loans_tab,
            text="Return Selected",
            command=self.do_return
        ).pack(anchor="w", pady=5)

        self.loan_tree = self.make_tree(
            self.loans_tab,
            (
                "id", "asset", "equipment", "borrower_code",
                "borrower", "borrowed", "due", "returned", "status"
            ),
            (
                "Loan ID", "Asset Code", "Equipment", "Borrower Code",
                "Borrower", "Borrowed", "Due", "Returned", "Status"
            )
        )

        self.loan_tree.column("id", width=65)

    def selected_id(self, tree):
        selection = tree.selection()

        if not selection:
            raise ValueError("Please select a record from the table first.")

        return int(tree.item(selection[0], "values")[0])

    def clear_fields(self, fields):
        for entry in fields.values():
            entry.delete(0, tk.END)

    def load_selected_asset(self, _event=None):
        """Copy the selected inventory row into the editable detail fields."""
        selection = self.asset_tree.selection()

        if not selection:
            return

        values = self.asset_tree.item(selection[0], "values")

        for label, value in zip(
            ["Asset Code", "Name", "Category", "Location", "Condition"],
            values[1:6]
        ):
            self.asset_fields[label].delete(0, tk.END)
            self.asset_fields[label].insert(0, value)

    def archive_asset(self):
        try:
            asset_id = self.selected_id(self.asset_tree)

            if not messagebox.askyesno(
                "Confirm",
                "Mark this equipment inactive? Its history will be kept."
            ):
                return

            deactivate_equipment(asset_id)
            self.refresh_all()

            messagebox.showinfo(
                "Success",
                "Equipment marked inactive. Its history was preserved."
            )

        except (ValueError, sqlite3.Error) as exc:
            messagebox.showerror("Cannot mark inactive", str(exc))

    def add_asset(self):
        try:
            values = [
                self.asset_fields[x].get()
                for x in [
                    "Asset Code", "Name", "Category", "Location", "Condition"
                ]
            ]

            add_equipment(*values)
            self.clear_fields(self.asset_fields)
            self.refresh_all()

            messagebox.showinfo("Success", "Equipment added.")

        except (ValueError, sqlite3.IntegrityError) as exc:
            messagebox.showerror(
                "Cannot add equipment",
                str(exc) if isinstance(exc, ValueError)
                else "Asset code already exists."
            )

    def update_asset(self):
        try:
            asset_id = self.selected_id(self.asset_tree)

            values = [
                self.asset_fields[x].get()
                for x in ["Name", "Category", "Location", "Condition"]
            ]

            update_equipment(asset_id, *values)
            self.refresh_all()

            messagebox.showinfo("Success", "Selected equipment updated.")

        except (ValueError, sqlite3.Error) as exc:
            messagebox.showerror("Cannot update equipment", str(exc))

    def add_person(self):
        try:
            values = [
                self.borrower_fields[x].get()
                for x in [
                    "Borrower Code", "Full Name", "Department / Program"
                ]
            ]

            add_borrower(*values)
            self.clear_fields(self.borrower_fields)
            self.refresh_all()

            messagebox.showinfo("Success", "Borrower registered.")

        except (ValueError, sqlite3.IntegrityError) as exc:
            messagebox.showerror(
                "Cannot register borrower",
                str(exc) if isinstance(exc, ValueError)
                else "Borrower code already exists."
            )

    def do_checkout(self):
        try:
            asset_id = int(self.asset_choice.get().split(" | ")[0])
            borrower_id = int(self.borrower_choice.get().split(" | ")[0])

            dispatch_action(
                "checkout",
                asset_id,
                borrower_id,
                self.borrow_date.get().strip(),
                self.due_date.get().strip()
            )

            self.refresh_all()
            messagebox.showinfo("Success", "Equipment checked out.")

        except (ValueError, IndexError, sqlite3.Error) as exc:
            messagebox.showerror("Checkout failed", str(exc))

    def do_return(self):
        try:
            loan_id = self.selected_id(self.loan_tree)

            dispatch_action("return", loan_id)
            self.refresh_all()

            messagebox.showinfo("Success", "Equipment returned.")

        except (ValueError, sqlite3.Error) as exc:
            messagebox.showerror("Return failed", str(exc))

    def refresh_inventory(self):
        for row in self.asset_tree.get_children():
            self.asset_tree.delete(row)

        for item in list_equipment(self.asset_search.get().strip()):
            self.asset_tree.insert(
                "",
                "end",
                values=(
                    item["asset_id"],
                    item["asset_code"],
                    item["name"],
                    item["category"],
                    item["location"],
                    item["condition"],
                    item["status"]
                )
            )

    def refresh_borrowers(self):
        for row in self.borrower_tree.get_children():
            self.borrower_tree.delete(row)

        for item in list_borrowers(self.borrower_search.get().strip()):
            self.borrower_tree.insert(
                "",
                "end",
                values=(
                    item["borrower_id"],
                    item["borrower_code"],
                    item["display_name"],
                    item["department_or_program"]
                )
            )

    def refresh_loans(self):
        for row in self.loan_tree.get_children():
            self.loan_tree.delete(row)

        for loan in list_loans():
            self.loan_tree.insert(
                "",
                "end",
                values=(
                    loan["loan_id"],
                    loan["asset_code"],
                    loan["equipment_name"],
                    loan["borrower_code"],
                    loan["display_name"],
                    loan["borrowed_on"],
                    loan["due_on"],
                    loan["returned_on"] or "-",
                    loan["display_status"]
                )
            )

        available = [
            x for x in list_equipment()
            if x["status"] == "Available"
        ]

        borrowers = list_borrowers()

        asset_values = [
            f'{x["asset_id"]} | {x["asset_code"]} - {x["name"]}'
            for x in available
        ]

        borrower_values = [
            f'{x["borrower_id"]} | {x["borrower_code"]} - {x["display_name"]}'
            for x in borrowers
        ]

        self.asset_choice["values"] = asset_values
        self.borrower_choice["values"] = borrower_values

        if self.asset_choice.get() not in asset_values:
            self.asset_choice.set(
                asset_values[0] if asset_values else ""
            )

        if self.borrower_choice.get() not in borrower_values:
            self.borrower_choice.set(
                borrower_values[0] if borrower_values else ""
            )

    def refresh_dashboard(self):
        report = get_dashboard_report()

        # Loop through the report dictionary to build the dashboard text.
        self.dashboard_text.set(
            "\n".join(
                f"{label}: {count}"
                for label, count in report.items()
            )
        )

    def refresh_all(self):
        self.refresh_inventory()
        self.refresh_borrowers()
        self.refresh_loans()
        self.refresh_dashboard()