"""Starts the CampusHub application."""

from database import initialize_database
from gui import CampusHubApp

def main():
    initialize_database()
    app = CampusHubApp()
    app.mainloop()

if __name__ == "__main__":
    main()
