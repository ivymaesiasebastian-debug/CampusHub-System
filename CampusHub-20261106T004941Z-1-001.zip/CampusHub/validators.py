"""Checks whether user inputs are valid."""

from datetime import date

def required(*values):
    return all(value is not None and str(value).strip() for value in values)

def valid_date(value):
    try:
        date.fromisoformat(value)
        return True
    except (ValueError, TypeError):
        return False

def valid_loan_dates(borrowed_on, due_on):
    if not valid_date(borrowed_on) or not valid_date(due_on):
        return False
    return date.fromisoformat(due_on) >= date.fromisoformat(borrowed_on)
