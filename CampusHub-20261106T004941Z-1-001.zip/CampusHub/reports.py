"""Calculates dashboard information, such as total equipment, available equipment, active loans, and overdue loans."""

from services import dashboard_counts, list_loans

def get_dashboard_report():
    total, available, active, overdue = dashboard_counts()
    return {
        "Total equipment": total,
        "Available equipment": available,
        "Active loans": active,
        "Overdue loans": overdue,
    }

def get_overdue_report():
    # Loop through loan records and keep only overdue loans.
    return [loan for loan in list_loans() if loan["display_status"] == "Overdue"]
